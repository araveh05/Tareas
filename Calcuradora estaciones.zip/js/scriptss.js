let numeroDeMes= prompt("ingrese el numero de un mes");
if ("numeroDeMes ˂1 || numeroDeMes ˃12"){
    alert ("valor invalido")
    }
let numroDeMes= prompt ("ingrese el numero de un mes")
    if ("numeroDeMes== 12 || numerodemes==1 || numerodemes==2"){
    alert("invierno")
    }
    
    if ("numeroDeMes== 3 || numerodemes==4 || numerodemes==5") {
    alert ("primavera")
    }
    if ("numerDeMes==6 || numerodemes==7 || numerodemes==8") {
        alert ("verano")
    }
    if ("numeroDeMes==9 || numerodemes==10 || numerodemes==11") {
        alert ("otoño")
    }
    alert("Maiyoryhernandez20008939");
